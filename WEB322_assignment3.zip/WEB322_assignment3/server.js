
const express = require("express");
const app = express();
var path = require("path");

const HTTP_PORT = process.env.PORT || 8080;

function onHttpStart() {
  console.log("Express http server listening on: " + HTTP_PORT);
}

app.use(express.urlencoded({ extended: true }));


app.get("/", function(req,res){
  res.sendFile(path.join(__dirname + "/views/main.html"));
});

app.get("/main.html", function(req,res){
   res.sendFile(path.join(__dirname + "/views/main.html"));
});

app.get("/mealPackage.html", function(req,res){
 res.sendFile(path.join(__dirname + "/views/mealPackage.html"));
});

app.get("/login.html", function(req, res){
  res.sendFile(path.join(__dirname + "/views/login.html"));
});

app.get("/registration.html", function(req, res){
  res.sendFile(path.join(__dirname + "/views/registration.html"))
});

app.post("/registered-user" , (req, res)=>{
  const formData = req.body;

  const dataReceived = "<h1>Welcome Back!</h1><br/>" + "<h3>User: " + req.body.email +"</h3><br/>" + "Your submission was received:<br/><br/>" +
    "Your form data was:<br/>" + JSON.stringify(formData) + "<br/>";
  res.send(dataReceived);
});

app.post("/new-user" , (req, res)=>{
  const formData = req.body;

  const dataReceived = "<h1>Welcome " + req.body.firstname + "<br/>" + "<h3>Your username is: " + req.body.email + "</h3><br/>" + "Your submission was received:<br/><br/>" + "Your form data was:<br/>" + JSON.stringify(formData) + "<br/><br/><br/>" + "Please Verify Your Information Below: <br/>" + "<table border = '1'><tr><th>First Name</th><th>Last Name</th><th>Email</th><th>Password</th></tr>" + "<tr><td>" + req.body.firstname + "</td> "+ "<td>" + req.body.lastname + "</td>" + "<td>" + req.body.email + "</td>" + "<td>" + req.body.password + "</td></tr>" +"</table>";
  res.send(dataReceived);
});


app.use(express.static('./public/'));



app.use((req, res) => {
  res.status(404).send("Page Not Found");
});


app.listen(HTTP_PORT, onHttpStart);